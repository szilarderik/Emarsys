from date_module.date import Date
from tests.test_date import test_calculate_date

if __name__ == '__main__':
    test_calculate_date()
